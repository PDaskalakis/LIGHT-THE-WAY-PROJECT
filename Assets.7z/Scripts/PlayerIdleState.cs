using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIdleState : PlayerBaseState
{
    public override void EnterState(PlayerStateManager manager)
    {
        //Change the animation to idle
    }
    public override void UpdateState(PlayerStateManager manager)
    {
        //keep gravity
        manager.applyGravity();

        if (manager.checkInput())
        {
            manager.SwitchState(manager.BasicFunctionsState);
        }
        //change the idle state if player moves
    }
}
