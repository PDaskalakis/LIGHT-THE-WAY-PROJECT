using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStateManager : MonoBehaviour
{
    //make the base state
    PlayerBaseState currentState;

    //initialize variables
    public CharacterController charController;

    //gravity
    public float grav;

    //Key distance
    public float distance;

    //initiallize states
    public PlayerBasicFunctionsState BasicFunctionsState = new PlayerBasicFunctionsState();
    public PlayerIdleState idleState = new PlayerIdleState();

    //Key bool
    public bool hasKey = false;

    //Key
    public Transform key;
    public void Start()
    {
        //set starting state
        currentState = idleState;

        //Cache the controller
        charController = GetComponent<CharacterController>();

        //set the start state of current state
        currentState.EnterState(this);
    }

    public void Update()
    {
        
        //run the update of every state
        currentState.UpdateState(this);

        //calculate gravity
        grav += Physics.gravity.y * Time.deltaTime;

        //Get key
        distance = Vector3.Distance(key.position, transform.position);

        if (distance < 1.59f)
        {
            hasKey = true;
            Destroy(key.gameObject);
        }

    }

    public void applyGravity()
    {
        //apply gravity
        Vector3 direction = new Vector3(0f, 0f, 0f).normalized;
        direction.y = grav;

        if (charController.isGrounded == true)
        {
            //reset gravity to 0
            grav = 0f;
        }

        //move
        charController.Move(direction * 5 * Time.deltaTime);
    }

    public bool checkInput()
    {
        //keys
        var Movement = Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D);
        var Jump = Input.GetKeyDown(KeyCode.Space);

        if (Movement || Jump)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void SwitchState(PlayerBaseState state)
    {
        //switch states
        currentState = state;
        state.EnterState(this);
    }


}
