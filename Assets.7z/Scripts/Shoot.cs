using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Shoot : MonoBehaviour
{
    public Vector3 screenPosition;

    public Vector3 worldPosition;

    float maxDistance = 100f;

    private void Update()
    {
        screenPosition = Input.mousePosition;
        screenPosition.z = 10;
        worldPosition = Camera.main.ScreenToWorldPoint(screenPosition);

        Vector3 mousePOS = Input.mousePosition;
        Ray ray = Camera.main.ScreenPointToRay(mousePOS);
        RaycastHit hit;

        Debug.DrawRay(transform.position, ray.direction * maxDistance);

        if (Physics.Raycast(ray, out hit, maxDistance))
        {
            if (hit.collider.gameObject.CompareTag("hit"))
            {
                Debug.Log("hit");
            }
        }
    } 
 }