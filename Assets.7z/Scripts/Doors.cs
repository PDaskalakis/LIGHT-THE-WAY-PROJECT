using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doors : MonoBehaviour
{
    [SerializeField]
    private bool Locked;

    [SerializeField]
    private bool Unlocked;

    [SerializeField]
    private Transform nextRoom;

    [SerializeField]
    private Transform player;

    private PlayerStateManager Player;

    public float distance;


    private void Update()
    {
        distance = Vector3.Distance(player.position, transform.position);

        //if (Player.hasKey == true)
        //{
        //    if (Locked)
        //    {
        //        Unlocked = true;
        //    }
        //}

        if (distance <= 1.70f)
        {
            if (Unlocked)
            {
                player.position = nextRoom.position;
            }
            else
            {
                return;
            }
        }
    }
}
