using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    float speed;
    private Vector3 target;
    private Vector3 start;
    private Vector3 offset;
    bool arrived = false;

    private void Start()
    {
        this.transform.position = start;
        speed = Random.Range(20f, 30f);
        offset = new Vector3(Random.Range(0.01f,0.0002f), Random.Range(0.01f, 0.0002f), Random.Range(0.01f, 0.0002f));
    }
    public void SetUp(Vector3 target, Vector3 start)
    {
        this.target = target;
        this.start = start;
    }

    public void Movement()
    {
        if (arrived == false)
        {
            this.transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
        }
        
        if ( this.transform.position == target)
        {
            arrived = true;
        }

        if (arrived == true)
        {
            this.transform.position += offset;

            if (transform.localScale != new Vector3(0.15f, 0.15f, 0.15f))
            {
                this.transform.localScale -= new Vector3(0.001f, 0.001f, 0.001f);
            }
            
            Destroy(this.gameObject,2f);
        }
    }

    private void Update()
    {
        Movement();
    }

}
