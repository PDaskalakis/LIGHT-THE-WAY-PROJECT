using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "hit")
        {
            collision.gameObject.GetComponent<Health>().currentHealth -= 20;
           
        }
       

        Destroy(this.gameObject);
    }
}
