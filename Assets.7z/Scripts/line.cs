using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class line : MonoBehaviour
{
    public Vector3 screenPosition;
    public Vector3 worldPosition;
    public bullet bull;

    float maxDistance = 100f;

    private void Update()
    {
        if (Input.GetKey(KeyCode.Mouse0))
        {
            Vector3 mousePOS = Input.mousePosition;
            Ray ray = Camera.main.ScreenPointToRay(mousePOS);
            RaycastHit hit;

            screenPosition = Input.mousePosition;
            screenPosition.z += 6.78f;
            worldPosition = Camera.main.ScreenToWorldPoint(screenPosition);

            bullet ammo = Instantiate(bull);
            ammo.SetUp(worldPosition, this.transform.position);

            if (Physics.Raycast(ray, out hit, maxDistance))
            {

                if (hit.collider.gameObject.CompareTag("hit"))
                {
                    Debug.Log("hit");

                    hit.collider.gameObject.GetComponent<Health>().ReduceHP();

                }
            }
        }
    }
}
