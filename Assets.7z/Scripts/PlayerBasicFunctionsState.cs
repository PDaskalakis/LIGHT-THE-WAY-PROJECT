using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBasicFunctionsState : PlayerBaseState
{
    //make the variables
    float speed = 5;
    float jumpSpeed = 3;

    float turnSmoothTime = 0.1f;
    float turnSmoothVelocity;
    

    public override void EnterState(PlayerStateManager manager)
    {
        
    }

    public override void UpdateState(PlayerStateManager manager)
    {
        //get input
        float vertical = Input.GetAxisRaw("Vertical");
        float horizontal = Input.GetAxisRaw("Horizontal");

        //calculate the direction vectors
        Vector3 direction = new Vector3(horizontal, 0f, vertical).normalized;
        direction.y = manager.grav;

        if (direction.magnitude >= 0.1f)
        {
            //calculate the changing of angles
            float directionAngle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;
            float angle = Mathf.SmoothDampAngle(manager.transform.eulerAngles.y, directionAngle, ref turnSmoothVelocity, turnSmoothTime);

            //rotate the character model
            manager.transform.rotation = Quaternion.Euler(0f, angle, 0f);

            //move
            manager.charController.Move(direction * speed * Time.deltaTime);
        }

        if(manager.charController.isGrounded == true)
        {
            //reset gravity to 0
            manager.grav = 0;

            //jump when spacebar is tapped
            if (Input.GetButtonDown("Jump"))
            {
                manager.grav = jumpSpeed;
            }
        }
    }
}
